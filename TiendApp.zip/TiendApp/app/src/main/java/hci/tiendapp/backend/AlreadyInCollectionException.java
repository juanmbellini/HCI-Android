package hci.tiendapp.backend;

/**
 * Created by Julian on 11/17/2015.
 */
public class AlreadyInCollectionException extends Exception {
    public AlreadyInCollectionException(String s) {
    }
}
