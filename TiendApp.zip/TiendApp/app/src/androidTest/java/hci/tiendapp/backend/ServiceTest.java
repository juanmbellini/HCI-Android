package hci.tiendapp.backend;



import junit.framework.TestCase;

/**
 * Created by Julian on 11/17/2015.
 */
public class ServiceTest extends TestCase {


    /*Service service = new Service();


    public void testRequest() throws Exception {
        Service service = new Service();
        service.connect("http://eiffel.itba.edu.ar/hci/service3/Common.groovy?method=GetAllStates");
    }*/
}